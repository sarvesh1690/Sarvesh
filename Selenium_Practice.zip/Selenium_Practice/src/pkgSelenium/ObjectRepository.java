package pkgSelenium;

public class ObjectRepository 
{
	public static final String sAllbutton = "//div[@class='col-12 mt-4 col-md-6']//div[@id='javascriptAlertsWrapper']/div/div[@class='col']/button";
	public static final String sAlert = "//div[@class='body-height']//div[@class='container playgound-body']//div[@class='row']//div[@class='col-12 mt-4  col-md-3']//div[@class='left-pannel']//div[@class='accordion']//div[@class='element-group' and position()=3]";
}
