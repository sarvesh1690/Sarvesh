package pkgSelenium;

import org.testng.annotations.Test;

public class One
{
  @Test(priority = 1)
  public void OpenBrowser() 
  {
	  GlobalClass.openBrowser();
  }
  
  @Test(priority = 2,enabled = true)
  public void AlertClick() throws Exception
  {
	  TestClass.clickAlert();
  }
}
