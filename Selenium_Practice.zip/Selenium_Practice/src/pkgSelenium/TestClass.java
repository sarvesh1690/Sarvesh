package pkgSelenium;

import java.awt.Robot;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestClass extends GlobalClass
{
	public static WebDriverWait wait = new WebDriverWait(driver,60);
	public static void clickAlert() throws Exception
	{
		WebElement alert = driver.findElement(By.xpath(ObjectRepository.sAlert));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ObjectRepository.sAlert)));
		
		if(alert.isDisplayed())
		{
			if(alert.isEnabled())
			{
				alert.click();
				Thread.sleep(3000);
				
				List<WebElement> buttons = driver.findElements(By.xpath(ObjectRepository.sAllbutton));
				int i =1;
				for(WebElement button : buttons)
				{
					button.click();
					if(i==2)
					{
						Thread.sleep(6000);
						driver.switchTo().alert().accept();
					}
					else if(i==4)
					{
						String s1="Abc";
						driver.switchTo().alert().sendKeys(s1);
						driver.switchTo().alert().accept();
						
						String web = driver.findElement(By.cssSelector("#promptResult")).getText();
						web = web.substring(12);
						
						if(driver.getPageSource().contains(web)){
							System.out.println("Text is present");
							}else{
							System.out.println("Text is absent");
							}
					}
					else
					{
						driver.switchTo().alert().accept();
					}
					i++;
				}
				
			}
			else
			{
				System.out.println("Not enable");
			}
		}
		else
		{
			System.out.println("Not displaying");
		}
	}
}
